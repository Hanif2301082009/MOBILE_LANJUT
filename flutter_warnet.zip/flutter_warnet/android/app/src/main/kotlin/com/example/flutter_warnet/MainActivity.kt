package com.example.flutter_warnet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
